# PROJECT REPORT: Student Notes Sharing System
## Database Management System (DBMS)

**Submitted by:** [Your Name]  
**Roll Number:** [Your Roll Number]  
**Course:** Bachelor of Computer Applications (BCA)  
**Semester/Section:** [Your Semester and Section]  
**Submitted to:** [Teacher's Name]  
**Institution:** Chandigarh University  
**Academic Session:** 2026–2027  

---

## 1. Abstract
The Student Notes Sharing System is a database project designed to organize study notes in one place. It stores note titles, descriptions, subjects, uploaders, file locations, and download history. MySQL is used to create relational tables and demonstrate SQL queries, constraints, joins, views, and indexes.

## 2. Introduction
Students often share study material through messages and separate folders. This can make notes difficult to find and manage. The proposed system organizes students, subjects, and note metadata in a relational database so information can be searched and reported efficiently.

## 3. Problem Statement
Manual notes sharing can cause duplicate or misplaced records, difficulty locating subject-wise notes, and no central download history. A structured database provides a consistent way to manage these records.

## 4. Objectives
- Maintain student records.
- Maintain subject and semester details.
- Store metadata about notes uploaded by students.
- Search notes by title or subject.
- Record which student downloaded a note and when.
- Demonstrate primary/foreign keys, constraints, joins, views, indexes, grouping, and transactions.

## 5. Scope
This is a DBMS-focused prototype. It stores a file path or URL for each note, not the actual PDF file. A website, login system, real file upload, and administrator approval can be added in a future version.

## 6. Hardware and Software Requirements
**Hardware:** Computer/laptop; 4 GB RAM or more recommended.  
**Software:** Windows, Linux, or macOS; MySQL Server 8.0+; MySQL Workbench recommended; any text editor.

## 7. Modules
1. **Student Management:** name, email, course, semester.
2. **Subject Management:** subject code, subject name, semester.
3. **Notes Management:** title, description, file path, uploader, subject, upload time, download count.
4. **Download Tracking:** note, student, and download time.
5. **Search and Reports:** keyword/subject search and summary queries.

## 8. Database Design

### 8.1 Tables
| Table | Purpose | Primary Key |
|---|---|---|
| students | Student details | student_id |
| subjects | Subject information | subject_id |
| notes | Notes metadata | note_id |
| downloads | Download history | download_id |

### 8.2 Relationships
- One student can upload many notes: `students (1) -> (many) notes`.
- One subject can have many notes: `subjects (1) -> (many) notes`.
- Students can download many notes, and a note can be downloaded by many students. The `downloads` table records this relationship and its time.

### 8.3 ER Diagram
```mermaid
erDiagram
    STUDENTS ||--o{ NOTES : uploads
    SUBJECTS ||--o{ NOTES : categorizes
    STUDENTS ||--o{ DOWNLOADS : makes
    NOTES ||--o{ DOWNLOADS : receives
    STUDENTS {
        int student_id PK
        varchar full_name
        varchar email UK
        varchar course
        tinyint semester
    }
    SUBJECTS {
        int subject_id PK
        varchar subject_code UK
        varchar subject_name
        tinyint semester
    }
    NOTES {
        int note_id PK
        varchar title
        text description
        varchar file_path
        int student_id FK
        int subject_id FK
        int download_count
    }
    DOWNLOADS {
        int download_id PK
        int note_id FK
        int student_id FK
        timestamp downloaded_at
    }
```

## 9. Normalization
- **1NF:** Each column contains a single value and each row has a primary key.
- **2NF:** Every non-key attribute depends on its table's complete primary key. These tables use single-column primary keys.
- **3NF:** Student details, subject details, note details, and download records are separated into related tables to reduce repetition and update anomalies.

## 10. SQL Concepts Used
- **DDL:** `CREATE DATABASE`, `CREATE TABLE`, `CREATE VIEW`, `CREATE INDEX`.
- **DML:** `INSERT`, `UPDATE`, `SELECT`.
- **Constraints:** `PRIMARY KEY`, `FOREIGN KEY`, `UNIQUE`, `NOT NULL`, `CHECK`, `DEFAULT`.
- **Queries:** `WHERE`, `LIKE`, `ORDER BY`, `LIMIT`.
- **Joins:** combine student, subject, note, and download details.
- **Aggregate functions:** `COUNT()`.
- **Grouping:** `GROUP BY`, `HAVING`.
- **Views and indexes:** simplify display and support common searches.
- **Transactions:** `START TRANSACTION` and `COMMIT`.

## 11. Implementation Steps
1. Run `sql/01_schema.sql` to create the database.
2. Run `sql/02_sample_data.sql` to add fictional demonstration records.
3. Run queries from `sql/03_queries.sql` one at a time.
4. Verify the `note_catalog` view and inspect table relationships.
5. Capture screenshots of successful execution for the final submission.

## 12. Testing
Test duplicate emails, invalid foreign keys, note search, joined note catalog, note counts, and download history. Expected outcomes are listed in `TESTING_GUIDE.md`.

## 13. Advantages
- Centralized note metadata.
- Easier subject-wise search.
- Less repeated student and subject data.
- Download history can be reviewed.
- Foreign keys help prevent invalid relationships.

## 14. Limitations
- No graphical website in this version.
- Actual PDF files are not uploaded into the database.
- Authentication and permissions are not implemented.
- Sample records are fictional.

## 15. Future Enhancements
- Create a website using HTML, CSS, JavaScript, PHP, or Python.
- Add student login and administrator roles.
- Add secure PDF file storage.
- Add ratings, comments, and note approval.
- Add pagination and advanced filters.

## 16. Conclusion
The Student Notes Sharing System demonstrates how MySQL can organize students, subjects, note metadata, and download history. It applies relational design, keys, constraints, views, indexes, joins, and aggregate queries. The database can later support a full web application.

## 17. References
- MySQL Reference Manual: https://dev.mysql.com/doc/
- MySQL Workbench Documentation: https://dev.mysql.com/doc/workbench/en/
- DBMS classroom notes.

## GitHub Repository
**Repository URL:** [Paste your GitHub repository URL here]
