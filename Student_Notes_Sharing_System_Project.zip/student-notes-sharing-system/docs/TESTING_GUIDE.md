# Testing Guide

Run `01_schema.sql`, then `02_sample_data.sql`, then execute the queries in `03_queries.sql`.

| Test ID | Test | Expected result |
|---|---|---|
| T01 | `SELECT COUNT(*) FROM students;` | 5 sample students |
| T02 | `SELECT COUNT(*) FROM subjects;` | 4 sample subjects |
| T03 | `SELECT COUNT(*) FROM notes;` | 6 sample notes |
| T04 | Query `note_catalog` | Each note shows uploader and subject |
| T05 | Search title with `LIKE '%DBMS%'` | DBMS-related titles appear |
| T06 | Group notes by subject | Count appears for each subject |
| T07 | Join downloads with students and notes | History shows names and note titles |
| T08 | Insert duplicate student email | Rejected because email is UNIQUE |
| T09 | Insert a note with a non-existent student ID | Rejected by foreign key |

## Screenshot checklist
Capture these from MySQL Workbench after running the project:
1. Schema and tables in the left navigator.
2. `SELECT * FROM students;`
3. `SELECT * FROM note_catalog;`
4. Most-downloaded notes result.
5. Download history result.

Add your real screenshots to the `screenshots` folder before submitting.
