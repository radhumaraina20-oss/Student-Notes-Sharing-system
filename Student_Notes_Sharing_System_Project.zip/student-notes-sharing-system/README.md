# Student Notes Sharing System (DBMS Project)

A beginner-friendly MySQL project for managing students, subjects, notes, and download history.

## Features
- Maintain student and subject records
- Store uploaded-note metadata and file paths
- Search notes by title or subject
- Track downloads and show popular notes
- Demonstrate PK, FK, UNIQUE, CHECK, JOIN, GROUP BY, HAVING, VIEW, INDEX, and transactions

## Technology
MySQL 8.0+ and MySQL Workbench (recommended). This is a database-focused project: the database stores the file path/URL, not the actual PDF.

## Files
- `sql/01_schema.sql` — database, tables, keys, constraints, indexes, and view
- `sql/02_sample_data.sql` — fictional demo records
- `sql/03_queries.sql` — example SQL queries
- `docs/PROJECT_REPORT.md` — project report draft
- `docs/TESTING_GUIDE.md` — test cases and screenshot checklist

## Run in MySQL Workbench
1. Connect to your local MySQL server.
2. Open and execute `sql/01_schema.sql`.
3. Open and execute `sql/02_sample_data.sql`.
4. Open `sql/03_queries.sql` and run queries one by one.
5. Refresh the Schemas panel and select `student_notes_db`.

## Run from the MySQL command line
```bash
mysql -u root -p < sql/01_schema.sql
mysql -u root -p < sql/02_sample_data.sql
mysql -u root -p student_notes_db < sql/03_queries.sql
```

## Upload to GitHub
Create a repository named `student-notes-sharing-system`, then upload these files. Or run from this folder:
```bash
git init
git add .
git commit -m "Add Student Notes Sharing System DBMS project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-notes-sharing-system.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## Before submission
- Run all three SQL files successfully.
- Take your own screenshots in MySQL Workbench and add them to `screenshots/`.
- Replace placeholders in `docs/PROJECT_REPORT.md` with your name, roll number, section, teacher name, and repository URL.
