USE student_notes_db;

INSERT INTO students (full_name, email, course, semester) VALUES
('Aarav Sharma', 'aarav@example.com', 'BCA', 3),
('Mehak Verma', 'mehak@example.com', 'BCA', 3),
('Kabir Singh', 'kabir@example.com', 'BCA', 2),
('Simran Kaur', 'simran@example.com', 'BCA', 3),
('Rohan Gupta', 'rohan@example.com', 'BCA', 2);

INSERT INTO subjects (subject_code, subject_name, semester) VALUES
('BCA301', 'Database Management System', 3),
('BCA302', 'Object Oriented Programming', 3),
('BCA203', 'Operating Systems', 2),
('BCA204', 'Data Structures', 2);

INSERT INTO notes (title, description, file_path, student_id, subject_id, download_count) VALUES
('DBMS Normalization Notes', '1NF, 2NF, 3NF and BCNF explained.', 'files/dbms_normalization.pdf', 1, 1, 12),
('SQL Joins Practice', 'INNER, LEFT, RIGHT and CROSS JOIN examples.', 'files/sql_joins.pdf', 2, 1, 8),
('OOP Concepts Revision', 'Classes, objects, inheritance and polymorphism.', 'files/oop_revision.pdf', 2, 2, 15),
('Operating System Scheduling', 'FCFS, SJF and Round Robin scheduling.', 'files/os_scheduling.pdf', 3, 3, 5),
('Data Structures Quick Guide', 'Arrays, stacks, queues and linked lists.', 'files/dsa_quick_guide.pdf', 4, 4, 9),
('DBMS ER Diagram Examples', 'ER diagrams and relationship types.', 'files/dbms_er_diagrams.pdf', 5, 1, 3);

INSERT INTO downloads (note_id, student_id) VALUES
(1, 2), (1, 3), (2, 1), (3, 1), (3, 4), (4, 5), (5, 2), (6, 3);
