-- Student Notes Sharing System | MySQL 8.0+
DROP DATABASE IF EXISTS student_notes_db;
CREATE DATABASE student_notes_db;
USE student_notes_db;

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    course VARCHAR(80) NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_student_semester CHECK (semester BETWEEN 1 AND 12)
);

CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_code VARCHAR(20) NOT NULL UNIQUE,
    subject_name VARCHAR(100) NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    CONSTRAINT chk_subject_semester CHECK (semester BETWEEN 1 AND 12)
);

CREATE TABLE notes (
    note_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    file_path VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    download_count INT UNSIGNED NOT NULL DEFAULT 0,
    CONSTRAINT fk_notes_student FOREIGN KEY (student_id)
        REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_notes_subject FOREIGN KEY (subject_id)
        REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_download_count CHECK (download_count >= 0)
);

CREATE TABLE downloads (
    download_id INT AUTO_INCREMENT PRIMARY KEY,
    note_id INT NOT NULL,
    student_id INT NOT NULL,
    downloaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_downloads_note FOREIGN KEY (note_id)
        REFERENCES notes(note_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_downloads_student FOREIGN KEY (student_id)
        REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX idx_notes_title ON notes(title);
CREATE INDEX idx_notes_subject ON notes(subject_id);
CREATE INDEX idx_notes_student ON notes(student_id);
CREATE INDEX idx_downloads_note ON downloads(note_id);

CREATE VIEW note_catalog AS
SELECT n.note_id, n.title, n.description, n.file_path, n.uploaded_at,
       n.download_count, s.full_name AS uploaded_by,
       sub.subject_code, sub.subject_name, sub.semester
FROM notes n
JOIN students s ON n.student_id = s.student_id
JOIN subjects sub ON n.subject_id = sub.subject_id;
