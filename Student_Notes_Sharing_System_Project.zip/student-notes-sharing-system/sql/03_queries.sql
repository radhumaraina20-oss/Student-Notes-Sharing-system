USE student_notes_db;

-- 1. All students
SELECT * FROM students ORDER BY full_name;

-- 2. All subjects
SELECT * FROM subjects ORDER BY semester, subject_name;

-- 3. Notes with uploader and subject (JOIN through a view)
SELECT note_id, title, subject_name, uploaded_by, download_count
FROM note_catalog ORDER BY subject_name, title;

-- 4. Search notes by keyword
SELECT * FROM note_catalog WHERE title LIKE '%DBMS%';

-- 5. Search notes for one subject
SELECT * FROM note_catalog
WHERE subject_name = 'Database Management System';

-- 6. Notes uploaded by each student (LEFT JOIN also shows zero uploads)
SELECT s.student_id, s.full_name, COUNT(n.note_id) AS total_notes
FROM students s LEFT JOIN notes n ON s.student_id = n.student_id
GROUP BY s.student_id, s.full_name
ORDER BY total_notes DESC, s.full_name;

-- 7. Top five most-downloaded notes
SELECT title, subject_name, download_count
FROM note_catalog ORDER BY download_count DESC LIMIT 5;

-- 8. Number of notes per subject
SELECT sub.subject_name, COUNT(n.note_id) AS total_notes
FROM subjects sub LEFT JOIN notes n ON sub.subject_id = n.subject_id
GROUP BY sub.subject_id, sub.subject_name
ORDER BY total_notes DESC;

-- 9. Download history
SELECT d.download_id, st.full_name AS downloaded_by, n.title, d.downloaded_at
FROM downloads d
JOIN students st ON d.student_id = st.student_id
JOIN notes n ON d.note_id = n.note_id
ORDER BY d.downloaded_at DESC;

-- 10. Example new student (uncomment to test)
-- INSERT INTO students (full_name, email, course, semester)
-- VALUES ('New Student', 'new.student@example.com', 'BCA', 3);

-- 11. Example new note (IDs must exist)
-- INSERT INTO notes (title, description, file_path, student_id, subject_id)
-- VALUES ('DBMS Transactions', 'ACID properties and transaction states.',
--         'files/dbms_transactions.pdf', 1, 1);

-- 12. Record a download and update its counter atomically (run together)
-- START TRANSACTION;
-- INSERT INTO downloads (note_id, student_id) VALUES (1, 2);
-- UPDATE notes SET download_count = download_count + 1 WHERE note_id = 1;
-- COMMIT;

-- 13. HAVING: students who uploaded at least two notes
SELECT s.full_name, COUNT(n.note_id) AS total_notes
FROM students s JOIN notes n ON s.student_id = n.student_id
GROUP BY s.student_id, s.full_name
HAVING COUNT(n.note_id) >= 2;
